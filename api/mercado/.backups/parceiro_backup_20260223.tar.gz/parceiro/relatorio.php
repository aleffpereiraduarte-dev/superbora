<?php
/**
 * GET /api/mercado/parceiro/relatorio.php?partner_id=1&periodo=mes
 */
require_once __DIR__ . "/../config/auth.php";

try {
    $db = getDB();

    // Autenticação obrigatória de parceiro
    $auth = om_auth()->requirePartner();
    $partner_id = $auth['uid'];

    $periodo = $_GET["periodo"] ?? "mes"; // dia, semana, mes

    // Validar período permitido
    $allowed_periods = ["dia", "semana", "mes"];
    if (!in_array($periodo, $allowed_periods)) {
        $periodo = "mes";
    }

    switch ($periodo) {
        case "dia":
            $where_data = "DATE(date_added) = CURRENT_DATE";
            break;
        case "semana":
            $where_data = "EXTRACT(WEEK FROM date_added) = EXTRACT(WEEK FROM NOW()) AND EXTRACT(YEAR FROM date_added) = EXTRACT(YEAR FROM NOW())";
            break;
        default:
            $where_data = "EXTRACT(MONTH FROM date_added) = EXTRACT(MONTH FROM NOW()) AND EXTRACT(YEAR FROM date_added) = EXTRACT(YEAR FROM NOW())";
    }

    // Total de pedidos
    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND $where_data");
    $stmt->execute([$partner_id]);
    $total_pedidos = $stmt->fetchColumn();

    // Pedidos entregues
    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND status = 'entregue' AND $where_data");
    $stmt->execute([$partner_id]);
    $pedidos_entregues = $stmt->fetchColumn();

    // Pedidos cancelados
    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND status = 'cancelado' AND $where_data");
    $stmt->execute([$partner_id]);
    $pedidos_cancelados = $stmt->fetchColumn();

    // Faturamento
    $stmt = $db->prepare("SELECT COALESCE(SUM(total), 0) FROM om_market_orders WHERE partner_id = ? AND status = 'entregue' AND $where_data");
    $stmt->execute([$partner_id]);
    $faturamento = $stmt->fetchColumn();

    // Ticket médio
    $stmt = $db->prepare("SELECT COALESCE(AVG(total), 0) FROM om_market_orders WHERE partner_id = ? AND status = 'entregue' AND $where_data");
    $stmt->execute([$partner_id]);
    $ticket_medio = $stmt->fetchColumn();

    $stats = [
        "total_pedidos" => (int)$total_pedidos,
        "pedidos_entregues" => (int)$pedidos_entregues,
        "pedidos_cancelados" => (int)$pedidos_cancelados,
        "faturamento" => (float)$faturamento,
        "ticket_medio" => (float)$ticket_medio,
    ];

    response(true, [
        "periodo" => $periodo,
        "estatisticas" => $stats
    ]);

} catch (Exception $e) {
    error_log("[parceiro/relatorio] Erro: " . $e->getMessage());
    response(false, null, 'Erro interno do servidor', 500);
}
