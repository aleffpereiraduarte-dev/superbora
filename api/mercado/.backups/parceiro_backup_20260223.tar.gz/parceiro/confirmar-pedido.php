<?php
/**
 * POST /api/mercado/parceiro/confirmar-pedido.php
 * Parceiro confirma que recebeu o pedido
 */
require_once __DIR__ . "/../config/auth.php";
require_once dirname(__DIR__, 2) . "/rate-limit/RateLimiter.php";

setCorsHeaders();

try {
    $input = getInput();
    $db = getDB();

    // Autenticação obrigatória de parceiro
    $auth = om_auth()->requirePartner();
    $partner_id = $auth['uid'];

    // Rate limit: 10 req/min per partner
    if (!RateLimiter::check(10, 60, 'confirmar_pedido_partner_' . $partner_id)) {
        exit;
    }

    $order_id = intval($input["order_id"] ?? 0);

    // SECURITY: Transaction + FOR UPDATE to prevent race condition
    $db->beginTransaction();

    $stmtPedido = $db->prepare("SELECT order_id, status FROM om_market_orders WHERE order_id = ? AND partner_id = ? FOR UPDATE");
    $stmtPedido->execute([$order_id, $partner_id]);
    $pedido = $stmtPedido->fetch();

    if (!$pedido) {
        $db->rollBack();
        response(false, null, "Pedido não encontrado", 404);
    }

    if ($pedido["status"] !== "pendente") {
        $db->rollBack();
        response(false, null, "Pedido não está pendente (status atual: {$pedido['status']})", 400);
    }

    // Atomic status transition
    $stmtUpd = $db->prepare("UPDATE om_market_orders SET status = 'confirmado', confirmed_at = NOW() WHERE order_id = ? AND status = 'pendente'");
    $stmtUpd->execute([$order_id]);

    if ($stmtUpd->rowCount() === 0) {
        $db->rollBack();
        response(false, null, "Pedido já foi alterado por outra requisição", 409);
    }

    $db->commit();

    response(true, [
        "order_id" => $order_id,
        "status" => "confirmado"
    ], "Pedido confirmado! Aguardando shopper aceitar.");
    
} catch (Exception $e) {
    error_log("[parceiro/confirmar-pedido] Erro: " . $e->getMessage());
    response(false, null, 'Erro interno do servidor', 500);
}
