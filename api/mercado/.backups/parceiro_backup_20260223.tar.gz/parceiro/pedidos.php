<?php
/**
 * GET /api/mercado/parceiro/pedidos.php?partner_id=1&status=pendente
 * Lista pedidos do parceiro (mercado)
 */
require_once __DIR__ . "/../config/auth.php";

try {
    $db = getDB();

    // Autenticacao de parceiro obrigatoria
    $auth = om_auth()->requirePartner();
    $partner_id = $auth['uid'];

    $status = $_GET["status"] ?? null;
    $data = $_GET["data"] ?? date("Y-m-d");

    // Validar status permitido
    $allowed_statuses = ["pendente", "aceito", "coletando", "em_entrega", "entregue", "cancelado"];
    if ($status && !in_array($status, $allowed_statuses)) {
        $status = null;
    }

    // Construir query com prepared statements
    $params = [$partner_id];
    $where = "o.partner_id = ?";

    if ($status) {
        $where .= " AND o.status = ?";
        $params[] = $status;
    }

    if ($data) {
        $where .= " AND DATE(o.date_added) = ?";
        $params[] = $data;
    }

    $sql = "SELECT o.*,
            c.firstname as cliente_nome, c.telephone as cliente_telefone,
            s.name as shopper_nome, s.phone as shopper_telefone,
            (SELECT COUNT(*) FROM om_market_order_items WHERE order_id = o.order_id) as total_itens
            FROM om_market_orders o
            LEFT JOIN oc_customer c ON o.customer_id = c.customer_id
            LEFT JOIN om_market_shoppers s ON o.shopper_id = s.shopper_id
            WHERE $where
            ORDER BY o.date_added DESC";

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $pedidos = $stmt->fetchAll();

    // Estatísticas
    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND status = 'pendente'");
    $stmt->execute([$partner_id]);
    $pendentes = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND status IN ('aceito','coletando','em_entrega')");
    $stmt->execute([$partner_id]);
    $em_andamento = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM om_market_orders WHERE partner_id = ? AND status = 'entregue' AND DATE(entrega_finalizada_em) = CURRENT_DATE");
    $stmt->execute([$partner_id]);
    $finalizados_hoje = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COALESCE(SUM(total), 0) FROM om_market_orders WHERE partner_id = ? AND status = 'entregue' AND DATE(entrega_finalizada_em) = CURRENT_DATE");
    $stmt->execute([$partner_id]);
    $faturamento_hoje = $stmt->fetchColumn();

    $stats = [
        "pendentes" => (int)$pendentes,
        "em_andamento" => (int)$em_andamento,
        "finalizados_hoje" => (int)$finalizados_hoje,
        "faturamento_hoje" => (float)$faturamento_hoje
    ];

    response(true, [
        "total" => count($pedidos),
        "estatisticas" => $stats,
        "pedidos" => array_map(function($p) {
            return [
                "order_id" => $p["order_id"],
                "status" => $p["status"],
                "total" => floatval($p["total"]),
                "total_itens" => $p["total_itens"],
                "cliente" => $p["cliente_nome"],
                "shopper" => $p["shopper_nome"],
                "endereco" => $p["delivery_address"],
                "criado_em" => $p["date_added"]
            ];
        }, $pedidos)
    ]);

} catch (Exception $e) {
    error_log("[parceiro/pedidos] Erro: " . $e->getMessage());
    response(false, null, 'Erro interno do servidor', 500);
}
