<?php
/**
 * POST /api/mercado/parceiro/push-subscribe.php
 * Registra push subscription do parceiro (user_type='parceiro')
 */
require_once __DIR__ . "/../config/auth.php";

setCorsHeaders();

try {
    $db = getDB();

    // SECURITY: JWT auth consistent with other partner endpoints (replaces session auth)
    $auth = om_auth()->requirePartner();
    $mercado_id = $auth['uid'];

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        response(false, null, "Metodo nao permitido", 405);
    }

    $input = getInput();
    $subscription = $input['subscription'] ?? null;

    if (!$subscription || !isset($subscription['endpoint'])) {
        response(false, null, "Subscription invalida", 400);
    }

    $endpoint = $subscription['endpoint'];
    $keys = $subscription['keys'] ?? [];
    $p256dh = $keys['p256dh'] ?? '';
    $auth = $keys['auth'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? null;

    // Upsert subscription como parceiro
    $stmt = $db->prepare("
        INSERT INTO om_push_subscriptions (customer_id, user_type, endpoint, p256dh, auth, user_agent, is_active)
        VALUES (?, 'parceiro', ?, ?, ?, ?, 1)
        ON CONFLICT (endpoint) DO UPDATE SET
            customer_id = EXCLUDED.customer_id,
            user_type = 'parceiro',
            p256dh = EXCLUDED.p256dh,
            auth = EXCLUDED.auth,
            is_active = '1'
    ");
    $stmt->execute([$mercado_id, $endpoint, $p256dh, $auth, $userAgent]);

    response(true, null, "Push subscription registrada");

} catch (Exception $e) {
    error_log("[push-subscribe] Erro: " . $e->getMessage());
    response(false, null, "Erro ao registrar push", 500);
}
