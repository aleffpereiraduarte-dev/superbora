<?php
/**
 * API - Status do Mercado (Aberto/Fechado)
 * Verifica horário de funcionamento e fechamentos especiais
 * Usado pelo app/site para mostrar status aos clientes
 */
require_once __DIR__ . "/../config/database.php";

try {
    $partner_id = intval($_GET['partner_id'] ?? $_GET['mercado_id'] ?? 0);

    if (!$partner_id) {
        response(false, null, "partner_id obrigatório", 400);
    }

    $db = getDB();

    // Buscar dados do mercado
    $stmt = $db->prepare("
        SELECT
            partner_id, name, logo, is_open,
            open_time, close_time,
            delivery_fee, min_order, delivery_time_min, delivery_time_max,
            rating
        FROM om_market_partners
        WHERE partner_id = ? AND status::text = '1'
    ");
    $stmt->execute([$partner_id]);
    $mercado = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$mercado) {
        response(false, null, "Mercado não encontrado", 404);
    }

    $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
    $hoje = $agora->format('Y-m-d');
    $dia_semana = (int)$agora->format('w');
    $hora_atual = $agora->format('H:i:s');

    // Verificar fechamento especial (feriado, férias)
    $stmt = $db->prepare("
        SELECT * FROM om_partner_closures
        WHERE partner_id = ?
        AND (
            closure_date = ?
            OR (closure_date <= ? AND closure_end >= ?)
        )
        LIMIT 1
    ");
    $stmt->execute([$partner_id, $hoje, $hoje, $hoje]);
    $fechamento = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verificar horário por dia da semana
    $stmt = $db->prepare("
        SELECT * FROM om_partner_hours
        WHERE partner_id = ? AND day_of_week = ?
    ");
    $stmt->execute([$partner_id, $dia_semana]);
    $horario_dia = $stmt->fetch(PDO::FETCH_ASSOC);

    // Determinar status
    $aberto = false;
    $motivo_fechado = null;
    $proximo_abertura = null;
    $horario_hoje = null;

    if (!$mercado['is_open']) {
        $motivo_fechado = 'Mercado temporariamente fechado';
    }
    elseif ($fechamento) {
        if ($fechamento['all_day']) {
            $motivo_fechado = $fechamento['reason'] ?? 'Fechado hoje';
        } else {
            $horario_hoje = [
                'abre' => substr($fechamento['open_time'], 0, 5),
                'fecha' => substr($fechamento['close_time'], 0, 5)
            ];
            $aberto = $hora_atual >= $fechamento['open_time'] && $hora_atual <= $fechamento['close_time'];
            if (!$aberto) {
                $motivo_fechado = 'Fora do horário especial';
            }
        }
    }
    elseif ($horario_dia && $horario_dia['is_closed']) {
        $motivo_fechado = 'Fechado hoje';
        for ($i = 1; $i <= 7; $i++) {
            $prox_dia = ($dia_semana + $i) % 7;
            $stmt = $db->prepare("SELECT * FROM om_partner_hours WHERE partner_id = ? AND day_of_week = ? AND is_closed = 0");
            $stmt->execute([$partner_id, $prox_dia]);
            $prox = $stmt->fetch();
            if ($prox) {
                $dias = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
                $proximo_abertura = $dias[$prox_dia] . ' às ' . substr($prox['open_time'], 0, 5);
                break;
            }
        }
    }
    else {
        $abre = $horario_dia['open_time'] ?? $mercado['open_time'] ?? '08:00:00';
        $fecha = $horario_dia['close_time'] ?? $mercado['close_time'] ?? '22:00:00';

        $horario_hoje = [
            'abre' => substr($abre, 0, 5),
            'fecha' => substr($fecha, 0, 5)
        ];

        $aberto = $hora_atual >= $abre && $hora_atual <= $fecha;

        if (!$aberto) {
            if ($hora_atual < $abre) {
                $motivo_fechado = 'Abre às ' . substr($abre, 0, 5);
            } else {
                $motivo_fechado = 'Fechado - abre amanhã';
            }
        }
    }

    // Buscar horários da semana
    $stmt = $db->prepare("SELECT * FROM om_partner_hours WHERE partner_id = ? ORDER BY day_of_week");
    $stmt->execute([$partner_id]);
    $horarios_semana = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $dias = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    $horarios_formatados = [];
    foreach ($horarios_semana as $h) {
        $horarios_formatados[] = [
            'dia' => $dias[$h['day_of_week']],
            'dia_semana' => $h['day_of_week'],
            'fechado' => (bool)$h['is_closed'],
            'abre' => $h['is_closed'] ? null : substr($h['open_time'], 0, 5),
            'fecha' => $h['is_closed'] ? null : substr($h['close_time'], 0, 5)
        ];
    }

    // Buscar próximos fechamentos
    $stmt = $db->prepare("
        SELECT closure_date, closure_end, reason
        FROM om_partner_closures
        WHERE partner_id = ? AND closure_date >= ?
        ORDER BY closure_date
        LIMIT 5
    ");
    $stmt->execute([$partner_id, $hoje]);
    $proximos_fechamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    response(true, [
        'mercado' => [
            'id' => $mercado['partner_id'],
            'nome' => $mercado['name'],
            'logo' => $mercado['logo'],
            'rating' => floatval($mercado['rating'])
        ],
        'status' => [
            'aberto' => $aberto,
            'motivo' => $motivo_fechado,
            'proximo_abertura' => $proximo_abertura,
            'horario_hoje' => $horario_hoje
        ],
        'entrega' => [
            'taxa' => floatval($mercado['delivery_fee']),
            'pedido_minimo' => floatval($mercado['min_order']),
            'tempo_min' => intval($mercado['delivery_time_min']),
            'tempo_max' => intval($mercado['delivery_time_max'])
        ],
        'horarios' => $horarios_formatados,
        'fechamentos' => $proximos_fechamentos
    ]);

} catch (Exception $e) {
    error_log("[parceiro/status] " . $e->getMessage());
    response(false, null, "Erro interno", 500);
}
