<?php
/**
 * POST /api/mercado/parceiro/cadastro.php
 * Cadastro de novo parceiro (mercado/restaurante/farmacia/loja)
 *
 * Body: { name, cnpj, email, senha, telefone, endereco, cidade, estado, cep, categoria, logo,
 *         owner_name, owner_cpf, owner_phone, razao_social, nome_fantasia,
 *         address_number, address_complement, bairro,
 *         bank_name, bank_agency, bank_account, pix_type, pix_key,
 *         terms_accepted, document_type (cnpj|cpf), display_name, specialty, lat, lng }
 * Rate limit: 3/hora
 * Insere com status=0 (pendente aprovacao) + retorna token para auto-login
 */
require_once __DIR__ . "/../config/database.php";
require_once dirname(__DIR__, 2) . "/rate-limit/RateLimiter.php";
require_once dirname(__DIR__, 3) . "/includes/classes/OmAuth.php";
require_once __DIR__ . "/../helpers/cnpj-lookup.php";

// Rate limit: 3 cadastros por hora
if (!RateLimiter::check(3, 3600)) {
    exit;
}

// Proper client IP detection (Cloudflare, proxy, direct)
$xForwardedFor = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
if ($xForwardedFor) {
    $xForwardedFor = explode(',', $xForwardedFor)[0]; // Take first IP only
    $xForwardedFor = trim($xForwardedFor);
}
$clientIp = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($xForwardedFor ?: ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));

try {
    $input = getInput();
    $db = getDB();

    // Sanitizar entrada - campos obrigatorios
    // Frontend envia: name, nomeApp → name; especialidade → specialty; responsavel_nome → owner_name
    $name = trim(substr($input['name'] ?? $input['nomeApp'] ?? '', 0, 255));
    $cnpj = preg_replace('/[^0-9]/', '', $input['cnpj'] ?? '');
    $email = filter_var(trim($input['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $senha = $input['senha'] ?? '';
    $telefone = preg_replace('/[^0-9+]/', '', $input['telefone'] ?? '');
    $endereco = trim(substr($input['endereco'] ?? '', 0, 500));
    $cidade = trim(substr($input['cidade'] ?? '', 0, 100));
    $estado = trim(substr($input['estado'] ?? '', 0, 2));
    $cep = preg_replace('/[^0-9]/', '', $input['cep'] ?? '');
    $display_name = trim(substr($input['display_name'] ?? $input['name'] ?? '', 0, 255));
    $specialty = trim(substr($input['specialty'] ?? $input['especialidade'] ?? '', 0, 255));
    $lat = isset($input['lat']) ? (float)$input['lat'] : null;
    $lng = isset($input['lng']) ? (float)$input['lng'] : null;
    $categoria = trim(substr($input['categoria'] ?? 'mercado', 0, 50));
    $logo = trim(substr($input['logo'] ?? '', 0, 500));

    // Validate logo URL if provided
    if ($logo && !filter_var($logo, FILTER_VALIDATE_URL)) {
        response(false, null, "URL do logo invalida", 400);
    }

    // Campos extras — aceita nomes do frontend e do API doc
    $owner_name = trim(substr($input['owner_name'] ?? $input['responsavel_nome'] ?? '', 0, 255));
    $owner_cpf = preg_replace('/[^0-9]/', '', $input['owner_cpf'] ?? $input['responsavel_cpf'] ?? '');
    $owner_phone = preg_replace('/[^0-9+]/', '', $input['owner_phone'] ?? $input['telefone'] ?? '');
    $razao_social = trim(substr($input['razao_social'] ?? '', 0, 255));
    $nome_fantasia = trim(substr($input['nome_fantasia'] ?? '', 0, 255));
    $address_number = trim(substr($input['address_number'] ?? $input['numero'] ?? '', 0, 20));
    $address_complement = trim(substr($input['address_complement'] ?? $input['complemento'] ?? '', 0, 255));
    $bairro = trim(substr($input['bairro'] ?? '', 0, 100));

    // Dados bancarios (opcionais)
    $bank_name = trim(substr($input['bank_name'] ?? '', 0, 100));
    $bank_agency = trim(substr($input['bank_agency'] ?? '', 0, 20));
    $bank_account = trim(substr($input['bank_account'] ?? '', 0, 30));
    $pix_type = $input['pix_type'] ?? null;
    $pix_key = trim(substr($input['pix_key'] ?? '', 0, 255));
    $terms_accepted = !empty($input['terms_accepted']);

    // Tipo de documento: cnpj (default) ou cpf
    // Frontend envia como 'doc_type', API doc usa 'document_type'
    $document_type = trim(strtolower($input['document_type'] ?? $input['doc_type'] ?? 'cnpj'));
    if (!in_array($document_type, ['cnpj', 'cpf'])) {
        $document_type = 'cnpj';
    }

    // Plano: basico (default) ou premium
    // Frontend envia como 'plano', API doc usa 'plan'
    $planSlug = trim(strtolower($input['plan'] ?? $input['plano'] ?? 'basico'));
    if (!in_array($planSlug, ['basico', 'premium'])) {
        $planSlug = 'basico';
    }

    // Validar pix_type
    $validPixTypes = ['cpf', 'cnpj', 'email', 'phone', 'random', null, ''];
    if (!in_array($pix_type, $validPixTypes)) $pix_type = null;
    if (empty($pix_type)) $pix_type = null;

    // Validacoes obrigatorias
    if (empty($name)) {
        response(false, null, "Nome da loja e obrigatorio", 400);
    }
    if (empty($owner_name)) {
        response(false, null, "Nome do responsavel e obrigatorio", 400);
    }
    // Validar documento conforme o tipo
    $cpf_value = null;
    $cpf_expiry_date = null;
    if ($document_type === 'cpf') {
        // Para CPF: frontend envia como 'cpf_empresa', API doc usa 'cpf'
        $cpf_value = preg_replace('/[^0-9]/', '', $input['cpf_empresa'] ?? $input['cpf'] ?? $input['cnpj'] ?? '');
        if (strlen($cpf_value) !== 11) {
            response(false, null, "CPF invalido (deve ter 11 digitos)", 400);
        }
        if (!validarCPF($cpf_value)) {
            response(false, null, "CPF invalido", 400);
        }
        $cpf_expiry_date = date('Y-m-d', strtotime('+1 year'));
    } else {
        if (strlen($cnpj) !== 14) {
            response(false, null, "CNPJ invalido (deve ter 14 digitos)", 400);
        }
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        response(false, null, "Email invalido", 400);
    }
    if (strlen($senha) < 8 || !preg_match('/[a-zA-Z]/', $senha) || !preg_match('/[0-9]/', $senha)) {
        response(false, null, "Senha deve ter no minimo 8 caracteres, incluindo pelo menos uma letra e um numero", 400);
    }
    if (empty($telefone) && empty($owner_phone)) {
        response(false, null, "Telefone e obrigatorio", 400);
    }

    $categorias_validas = ['mercado', 'restaurante', 'farmacia', 'loja', 'padaria', 'acougue', 'hortifruti', 'petshop', 'conveniencia', 'bebidas', 'outros'];
    if (!in_array($categoria, $categorias_validas)) {
        $categoria = 'outros';
    }

    // Validar CPF do proprietario se fornecido (independente do document_type)
    if (!empty($owner_cpf) && !validarCPF($owner_cpf)) {
        response(false, null, "CPF do proprietario invalido", 400);
    }

    // ── Validacao e lookup conforme document_type ────────────────────────
    $cnaeInfo = ['cnae_principal' => null, 'cnae_descricao' => null, 'cnpj_situacao' => null];

    if ($document_type === 'cnpj') {
        // Validar CNPJ (checksum)
        if (!validarCNPJ($cnpj)) {
            response(false, null, "CNPJ invalido", 400);
        }

        // ── Consultar CNPJ na BrasilAPI ─────────────────────────────────
        $brasilApiResult = consultarCNPJ($cnpj);

        if ($brasilApiResult['success']) {
            $apiData = $brasilApiResult['data'];

            // Bloquear se CNPJ nao esta ATIVO (situacao_cadastral != 2)
            if ($apiData['situacao_cadastral'] !== 2) {
                response(false, null, "CNPJ com situacao: " . $apiData['descricao_situacao_cadastral'] . ". Apenas CNPJs com situacao ATIVA podem se cadastrar.", 400);
            }

            // Validar CNAE (ramo alimenticio)
            $cnaeResult = validarCNAE($apiData['cnae_fiscal'], $apiData['cnaes_secundarios']);
            if (!$cnaeResult['valid']) {
                response(false, null, "O CNPJ informado nao pertence ao ramo alimenticio ou de comercio compativel com a plataforma. CNAE principal: " . $apiData['cnae_fiscal'] . " - " . $apiData['cnae_fiscal_descricao'], 400);
            }

            // Auto-preencher campos se vazios
            if (empty($razao_social) && !empty($apiData['razao_social'])) {
                $razao_social = substr($apiData['razao_social'], 0, 255);
            }
            if (empty($nome_fantasia) && !empty($apiData['nome_fantasia'])) {
                $nome_fantasia = substr($apiData['nome_fantasia'], 0, 255);
            }

            $cnaeInfo['cnae_principal'] = substr($apiData['cnae_fiscal'], 0, 20);
            $cnaeInfo['cnae_descricao'] = substr($cnaeResult['matched_descricao'], 0, 255);
            $cnaeInfo['cnpj_situacao'] = substr($apiData['descricao_situacao_cadastral'], 0, 30);
        } else {
            // API falhou - log e continua (admin valida manualmente na aprovacao)
            error_log("[cadastro-parceiro] BrasilAPI falhou para CNPJ {$cnpj}: " . $brasilApiResult['error']);
        }
    }
    // CPF path: skip BrasilAPI lookup and CNAE validation

    // Resolver plan_id
    $stmtPlan = $db->prepare("SELECT id, slug, commission_rate, commission_online_rate FROM om_partner_plans WHERE slug = ? AND status::text = '1'");
    $stmtPlan->execute([$planSlug]);
    $planRow = $stmtPlan->fetch();
    $planId = $planRow ? (int)$planRow['id'] : 1; // fallback para basico

    // Determinar entrega_propria e commission_rate baseado no plano
    $entregaPropria = ($planSlug === 'premium') ? 0 : 1; // Basico = entrega propria, Premium = BoraUm
    $commissionRate = ($planSlug === 'premium') ? 18.00 : 10.00;

    // Verificar duplicado: documento
    if ($document_type === 'cpf') {
        $stmt = $db->prepare("SELECT partner_id FROM om_market_partners WHERE cpf = ? AND document_type = 'cpf'");
        $stmt->execute([$cpf_value]);
        if ($stmt->fetch()) {
            response(false, null, "CPF ja cadastrado", 409);
        }
    } else {
        $stmt = $db->prepare("SELECT partner_id FROM om_market_partners WHERE cnpj = ?");
        $stmt->execute([$cnpj]);
        if ($stmt->fetch()) {
            response(false, null, "CNPJ ja cadastrado", 409);
        }
    }

    // Verificar duplicado: Email
    $stmt = $db->prepare("SELECT partner_id FROM om_market_partners WHERE email = ? OR login_email = ?");
    $stmt->execute([$email, $email]);
    if ($stmt->fetch()) {
        response(false, null, "Email ja cadastrado", 409);
    }

    // Hash da senha
    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

    // Use owner_name as store name fallback
    $storeName = !empty($nome_fantasia) ? $nome_fantasia : (!empty($name) ? $name : $owner_name);
    $phone = !empty($owner_phone) ? $owner_phone : $telefone;

    // Inserir com status=0 (pendente)
    $stmt = $db->prepare("
        INSERT INTO om_market_partners
        (name, owner_name, owner_cpf, owner_phone, cnpj, razao_social, nome_fantasia,
         email, login_email, login_password, phone,
         address, address_number, address_complement, bairro, city, state, cep,
         logo, status, categoria, registration_step,
         bank_name, bank_agency, bank_account, pix_type, pix_key,
         cnae_principal, cnae_descricao, cnpj_situacao, plan_id,
         entrega_propria, commission_rate,
         terms_accepted_at, document_type, cpf, cpf_expiry_date,
         display_name, specialty, lat, lng,
         created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?, ?,
                ?, '0', ?, 5,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?,
                ?, ?,
                ?, ?, ?, ?,
                ?, ?, ?, ?,
                NOW())
        RETURNING partner_id
    ");
    $stmt->execute([
        $storeName, $owner_name ?: null, $owner_cpf ?: null, $owner_phone ?: null,
        $document_type === 'cnpj' ? $cnpj : null, $razao_social ?: null, $nome_fantasia ?: null,
        $email, $email, $senhaHash, $phone,
        $endereco, $address_number ?: null, $address_complement ?: null, $bairro ?: null,
        $cidade, $estado, $cep,
        $logo, $categoria,
        $bank_name ?: null, $bank_agency ?: null, $bank_account ?: null,
        $pix_type, $pix_key ?: null,
        $cnaeInfo['cnae_principal'], $cnaeInfo['cnae_descricao'], $cnaeInfo['cnpj_situacao'], $planId,
        $entregaPropria, $commissionRate,
        $terms_accepted ? date('Y-m-d H:i:s') : null,
        $document_type, $cpf_value, $cpf_expiry_date,
        $display_name ?: null, $specialty ?: null, $lat, $lng
    ]);

    $partner_id = (int)$stmt->fetchColumn();

    // Criar registro de saldo do parceiro
    try {
        $db->prepare("
            INSERT INTO om_mercado_saldo (partner_id, saldo_disponivel, saldo_pendente, total_recebido, total_sacado, saldo_devedor)
            VALUES (?, 0, 0, 0, 0, 0)
            ON CONFLICT (partner_id) DO NOTHING
        ")->execute([$partner_id]);
    } catch (Exception $e) {
        error_log("[cadastro-parceiro] Erro ao criar saldo: " . $e->getMessage());
    }

    // Generate auto-login token
    OmAuth::getInstance()->setDb($db);
    $token = om_auth()->generateToken('partner', $partner_id);

    // Notificar admin (log por enquanto)
    $docLog = $document_type === 'cpf' ? "CPF: $cpf_value" : "CNPJ: $cnpj";
    error_log("[NOVO PARCEIRO] ID: $partner_id | Nome: $storeName | $docLog | Email: $email | Categoria: $categoria | Tipo: $document_type");

    response(true, [
        "partner_id" => $partner_id,
        "token" => $token,
        "status" => "pendente",
        "partner" => [
            "id" => $partner_id,
            "nome" => $storeName,
            "razao_social" => $razao_social ?: null,
            "nome_fantasia" => $nome_fantasia ?: null,
            "email" => $email,
            "document_type" => $document_type,
            "cnpj" => $document_type === 'cnpj' ? $cnpj : null,
            "cpf" => $cpf_value,
            "cpf_expiry_date" => $cpf_expiry_date,
            "display_name" => $display_name ?: null,
            "specialty" => $specialty ?: null,
            "lat" => $lat,
            "lng" => $lng,
            "categoria" => $categoria,
            "status" => 0,
            "logo" => $logo,
            "cnae_principal" => $cnaeInfo['cnae_principal'],
            "cnae_descricao" => $cnaeInfo['cnae_descricao'],
            "plano" => [
                "slug" => $planSlug,
                "nome" => $planRow ? $planRow['slug'] : 'basico',
            ],
        ]
    ], "Cadastro realizado! Aguarde a aprovacao da nossa equipe.");

} catch (Exception $e) {
    error_log("[cadastro-parceiro] Erro: " . $e->getMessage());
    response(false, null, "Erro ao realizar cadastro. Tente novamente.", 500);
}

/**
 * Validacao basica de CNPJ
 */
function validarCNPJ(string $cnpj): bool {
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    if (strlen($cnpj) !== 14) return false;

    // Rejeitar CNPJs com todos digitos iguais
    if (preg_match('/^(\d)\1{13}$/', $cnpj)) return false;

    // Validar digitos verificadores
    $tamanho = strlen($cnpj) - 2;
    $numeros = substr($cnpj, 0, $tamanho);
    $digitos = substr($cnpj, $tamanho);

    $soma = 0;
    $pos = $tamanho - 7;
    for ($i = $tamanho; $i >= 1; $i--) {
        $soma += $numeros[$tamanho - $i] * $pos--;
        if ($pos < 2) $pos = 9;
    }
    $resultado = $soma % 11 < 2 ? 0 : 11 - $soma % 11;
    if ($resultado != $digitos[0]) return false;

    $tamanho++;
    $numeros = substr($cnpj, 0, $tamanho);
    $soma = 0;
    $pos = $tamanho - 7;
    for ($i = $tamanho; $i >= 1; $i--) {
        $soma += $numeros[$tamanho - $i] * $pos--;
        if ($pos < 2) $pos = 9;
    }
    $resultado = $soma % 11 < 2 ? 0 : 11 - $soma % 11;
    if ($resultado != $digitos[1]) return false;

    return true;
}

/**
 * Validacao de CPF (mod-11)
 */
function validarCPF(string $cpf): bool {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) !== 11) return false;

    // Rejeitar CPFs com todos digitos iguais
    if (preg_match('/^(\d)\1{10}$/', $cpf)) return false;

    // Validar primeiro digito verificador
    $soma = 0;
    for ($i = 0; $i < 9; $i++) {
        $soma += (int)$cpf[$i] * (10 - $i);
    }
    $resto = $soma % 11;
    $d1 = $resto < 2 ? 0 : 11 - $resto;
    if ((int)$cpf[9] !== $d1) return false;

    // Validar segundo digito verificador
    $soma = 0;
    for ($i = 0; $i < 10; $i++) {
        $soma += (int)$cpf[$i] * (11 - $i);
    }
    $resto = $soma % 11;
    $d2 = $resto < 2 ? 0 : 11 - $resto;
    if ((int)$cpf[10] !== $d2) return false;

    return true;
}
