<?php
/**
 * GET/POST /api/mercado/parceiro/contrato.php
 * GET  - Retorna texto do contrato pre-preenchido com dados do parceiro
 * POST - Assina o contrato digitalmente
 *
 * Body POST: { signer_name, signer_document }
 * Auth: Bearer token (partner)
 */
require_once __DIR__ . "/../config/database.php";
require_once dirname(__DIR__, 3) . "/includes/classes/OmAuth.php";

setCorsHeaders();

try {
    $db = getDB();
    OmAuth::getInstance()->setDb($db);

    $token = om_auth()->getTokenFromRequest();
    if (!$token) response(false, null, "Token ausente", 401);

    $payload = om_auth()->validateToken($token);
    if (!$payload || $payload['type'] !== OmAuth::USER_TYPE_PARTNER) {
        response(false, null, "Nao autorizado", 401);
    }
    $partnerId = (int)$payload['uid'];

    // ── Carregar dados do parceiro ──────────────────────────────────────
    $stmt = $db->prepare("
        SELECT p.partner_id, p.name, p.owner_name, p.cnpj, p.cpf, p.document_type,
               p.razao_social, p.nome_fantasia, p.email, p.phone,
               p.address, p.address_number, p.address_complement, p.bairro,
               p.city, p.state, p.cep, p.categoria,
               p.plan_id, p.contract_signed_at,
               pl.slug AS plan_slug, pl.commission_rate, pl.commission_online_rate,
               pl.uses_platform_delivery
        FROM om_market_partners p
        LEFT JOIN om_partner_plans pl ON pl.id = p.plan_id
        WHERE p.partner_id = ?
    ");
    $stmt->execute([$partnerId]);
    $partner = $stmt->fetch();

    if (!$partner) {
        response(false, null, "Parceiro nao encontrado", 404);
    }

    // BUG #41: Prevent duplicate contract signing
    if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($partner['contract_signed_at'])) {
        response(false, null, "Contrato ja foi assinado", 400);
    }

    // ── Montar dados para o contrato ────────────────────────────────────
    $planSlug = $partner['plan_slug'] ?? 'basico';
    $planLabel = $planSlug === 'premium' ? 'Premium' : 'Basico';
    $commissionRate = (float)($partner['commission_rate'] ?? 5.00);
    $commissionOnlineRate = (float)($partner['commission_online_rate'] ?? 8.00);
    $usesPlatformDelivery = (bool)($partner['uses_platform_delivery'] ?? false);

    $partnerName = $partner['nome_fantasia'] ?: $partner['name'] ?: $partner['owner_name'];
    $razaoSocial = $partner['razao_social'] ?: $partnerName;
    $documentType = $partner['document_type'] ?? 'cnpj';

    if ($documentType === 'cpf' && !empty($partner['cpf'])) {
        $docNumber = $partner['cpf'];
        $docLabel = 'CPF';
        $docFormatted = preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $docNumber);
    } else {
        $docNumber = $partner['cnpj'] ?? '';
        $docLabel = 'CNPJ';
        $docFormatted = preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $docNumber);
    }

    // Endereco completo
    $addressParts = array_filter([
        $partner['address'],
        $partner['address_number'] ? 'n. ' . $partner['address_number'] : null,
        $partner['address_complement'],
        $partner['bairro'],
        $partner['city'],
        $partner['state'],
        $partner['cep'] ? 'CEP ' . $partner['cep'] : null,
    ]);
    $fullAddress = implode(', ', $addressParts) ?: 'Endereco nao informado';

    $dataAtual = (new DateTime('now', new DateTimeZone('America/Sao_Paulo')))->format('d/m/Y');

    // ── Gerar texto do contrato ─────────────────────────────────────────
    $contractText = gerarTextoContrato(
        $partnerName,
        $razaoSocial,
        $docLabel,
        $docFormatted,
        $fullAddress,
        $planLabel,
        $commissionRate,
        $commissionOnlineRate,
        $usesPlatformDelivery,
        $dataAtual,
        $partner['categoria'] ?? 'mercado'
    );

    // ═════════════════════════════════════════════════════════════════════
    // GET - Retorna contrato para visualizacao
    // ═════════════════════════════════════════════════════════════════════
    if ($_SERVER["REQUEST_METHOD"] === "GET") {
        response(true, [
            "partner" => [
                "id" => (int)$partner['partner_id'],
                "name" => $partnerName,
                "razao_social" => $razaoSocial,
                "document_type" => $documentType,
                "document_number" => $docFormatted,
                "email" => $partner['email'],
                "address" => $fullAddress,
                "plan" => $planLabel,
                "commission_rate" => $commissionRate,
                "commission_online_rate" => $commissionOnlineRate,
                "already_signed" => !empty($partner['contract_signed_at']),
                "signed_at" => $partner['contract_signed_at'],
            ],
            "contract_text" => $contractText,
            "generated_at" => date('c'),
        ], "Contrato gerado com sucesso");
    }

    // ═════════════════════════════════════════════════════════════════════
    // POST - Assinar contrato
    // ═════════════════════════════════════════════════════════════════════
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $input = getInput();

        $signerName = trim(substr($input['signer_name'] ?? '', 0, 255));
        $signerDocument = preg_replace('/[^0-9]/', '', $input['signer_document'] ?? '');

        if (empty($signerName)) {
            response(false, null, "Nome do assinante e obrigatorio", 400);
        }
        if (empty($signerDocument)) {
            response(false, null, "Documento do assinante e obrigatorio", 400);
        }
        // Validate signer_document as valid CPF (11 digits) or CNPJ (14 digits)
        if (strlen($signerDocument) !== 11 && strlen($signerDocument) !== 14) {
            response(false, null, "Documento invalido. Informe um CPF (11 digitos) ou CNPJ (14 digitos)", 400);
        }

        $xFwd = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
        if ($xFwd) { $xFwd = trim(explode(',', $xFwd)[0]); }
        $signerIp = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? ($xFwd ?: ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'));
        $signerUserAgent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'unknown', 0, 500);

        $db->beginTransaction();
        try {
            // Inserir contrato assinado
            $stmt = $db->prepare("
                INSERT INTO om_partner_contracts
                    (partner_id, plan_slug, contract_text, signed_at,
                     signer_name, signer_document, signer_ip, signer_user_agent, status)
                VALUES (?, ?, ?, NOW(), ?, ?, ?, ?, 'signed')
            ");
            $stmt->execute([
                $partnerId,
                $planSlug,
                $contractText,
                $signerName,
                $signerDocument,
                $signerIp,
                $signerUserAgent,
            ]);

            $contractId = (int)$db->lastInsertId();

            // Atualizar parceiro com dados da assinatura
            $stmt = $db->prepare("
                UPDATE om_market_partners
                SET contract_signed_at = NOW(),
                    contract_ip = ?
                WHERE partner_id = ?
            ");
            $stmt->execute([$signerIp, $partnerId]);

            $db->commit();

            error_log("[contrato] Parceiro #{$partnerId} assinou contrato #{$contractId} | IP: {$signerIp}");

            response(true, [
                "contract_id" => $contractId,
                "partner_id" => $partnerId,
                "plan" => $planLabel,
                "signed_at" => date('c'),
                "signer_name" => $signerName,
            ], "Contrato assinado com sucesso");

        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

    // Metodo nao permitido
    response(false, null, "Metodo nao permitido", 405);

} catch (Exception $e) {
    error_log("[parceiro/contrato] Erro: " . $e->getMessage());
    response(false, null, "Erro ao processar contrato", 500);
}

// ═════════════════════════════════════════════════════════════════════════════
// FUNCAO: Gera texto completo do contrato
// ═════════════════════════════════════════════════════════════════════════════
function gerarTextoContrato(
    string $partnerName,
    string $razaoSocial,
    string $docLabel,
    string $docFormatted,
    string $fullAddress,
    string $planLabel,
    float $commissionRate,
    float $commissionOnlineRate,
    bool $usesPlatformDelivery,
    string $dataAtual,
    string $categoria
): string {

    $deliveryClause = $usesPlatformDelivery
        ? "A PLATAFORMA disponibilizara servico de entrega atraves de entregadores parceiros, sendo o custo de entrega repassado ao consumidor final."
        : "O PARCEIRO sera responsavel por realizar suas proprias entregas, podendo optar pelo servico de entrega da PLATAFORMA quando disponivel.";

    $categoriaLabel = match($categoria) {
        'restaurante' => 'restaurante',
        'farmacia' => 'farmacia',
        'padaria' => 'padaria',
        'acougue' => 'acougue',
        'hortifruti' => 'hortifruti',
        'petshop' => 'petshop',
        'conveniencia' => 'loja de conveniencia',
        'bebidas' => 'loja de bebidas',
        'loja' => 'loja',
        default => 'estabelecimento comercial',
    };

    $contract = <<<CONTRACT
CONTRATO DE ADESAO E PARCERIA COMERCIAL
PLATAFORMA SUPERBORA DELIVERY

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IDENTIFICACAO DAS PARTES

CONTRATANTE (PLATAFORMA): SUPERBORA DELIVERY, plataforma digital de intermediacao de pedidos e entregas, de propriedade de ONEMUNDO TECNOLOGIA LTDA, doravante denominada simplesmente "PLATAFORMA".

CONTRATADO (PARCEIRO): {$razaoSocial}, {$categoriaLabel}, inscrito no {$docLabel} sob o numero {$docFormatted}, com sede/endereco em {$fullAddress}, doravante denominado simplesmente "PARCEIRO".

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 1 - DO OBJETO

1.1. O presente contrato tem por objeto estabelecer as condicoes comerciais para a intermediacao de vendas de produtos do PARCEIRO atraves da PLATAFORMA SuperBora Delivery, incluindo a exibicao de produtos, processamento de pedidos e pagamentos.

1.2. A PLATAFORMA atuara como intermediadora entre o PARCEIRO e os consumidores finais, disponibilizando tecnologia para realizacao de pedidos online, aplicativo movel e painel de gestao.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 2 - DO PLANO E CONDICOES COMERCIAIS

2.1. O PARCEIRO adere ao Plano {$planLabel}, com as seguintes condicoes:

   a) Taxa de comissao sobre vendas com pagamento em dinheiro/PIX presencial: {$commissionRate}% (por cento) sobre o valor dos produtos.

   b) Taxa de comissao sobre vendas com pagamento online (cartao de credito, debito ou PIX via plataforma): {$commissionOnlineRate}% (por cento) sobre o valor dos produtos.

   c) As taxas de comissao incidem exclusivamente sobre o valor dos produtos vendidos, nao incidindo sobre a taxa de entrega cobrada do consumidor.

2.2. {$deliveryClause}

2.3. Os repasses serao realizados conforme calendario financeiro da PLATAFORMA, com periodicidade semanal ou quinzenal, descontadas as comissoes previstas neste contrato.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 3 - DAS OBRIGACOES DA PLATAFORMA

A PLATAFORMA se compromete a:

3.1. Disponibilizar o aplicativo e site para exibicao dos produtos e cardapio do PARCEIRO aos consumidores.

3.2. Processar os pagamentos online realizados pelos consumidores e repassar os valores devidos ao PARCEIRO conforme os prazos estabelecidos.

3.3. Fornecer painel administrativo para gestao de pedidos, cardapio, horarios de funcionamento e relatorios financeiros.

3.4. Oferecer suporte tecnico para utilizacao da plataforma.

3.5. Realizar acoes de marketing digital para atrair consumidores a plataforma.

3.6. Manter a seguranca dos dados conforme a Lei Geral de Protecao de Dados (LGPD - Lei 13.709/2018).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 4 - DAS OBRIGACOES DO PARCEIRO

O PARCEIRO se compromete a:

4.1. Manter o cadastro atualizado na plataforma, incluindo cardapio, precos, horarios de funcionamento e informacoes de contato.

4.2. Garantir a qualidade dos produtos oferecidos, atendendo as normas sanitarias e de seguranca alimentar aplicaveis.

4.3. Cumprir os horarios de funcionamento cadastrados na plataforma.

4.4. Preparar e disponibilizar os pedidos dentro do tempo estimado informado na plataforma.

4.5. Manter os precos praticados na plataforma compativeis com os precos praticados no estabelecimento fisico, salvo acordo especifico.

4.6. Comunicar a PLATAFORMA com antecedencia sobre fechamentos extraordinarios, alteracoes de cardapio ou qualquer situacao que afete o atendimento.

4.7. Respeitar o Codigo de Defesa do Consumidor (Lei 8.078/1990) em todas as transacoes realizadas atraves da plataforma.

4.8. Manter regularidade fiscal e documental do estabelecimento durante a vigencia deste contrato.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 5 - DA VIGENCIA E RESCISAO

5.1. O presente contrato e firmado por prazo indeterminado, entrando em vigor na data de sua assinatura digital.

5.2. Qualquer das partes podera rescindir este contrato a qualquer momento, mediante comunicacao previa de 30 (trinta) dias, sem incidencia de multa ou penalidade.

5.3. A rescisao nao exime as partes das obrigacoes pendentes, incluindo repasses financeiros de pedidos ja realizados.

5.4. A PLATAFORMA reserva-se o direito de suspender ou rescindir este contrato imediatamente em caso de:
   a) Violacao das obrigacoes previstas neste contrato;
   b) Praticas que prejudiquem a reputacao da plataforma;
   c) Fraude ou tentativa de fraude;
   d) Descumprimento de normas sanitarias ou legais.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 6 - DA PROPRIEDADE INTELECTUAL

6.1. As marcas, logotipos, softwares e demais elementos de propriedade intelectual da PLATAFORMA permanecem de titularidade exclusiva da ONEMUNDO TECNOLOGIA LTDA.

6.2. O PARCEIRO autoriza a PLATAFORMA a utilizar seu nome, marca e imagens dos produtos para fins de divulgacao na plataforma e em materiais de marketing.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 7 - DA PROTECAO DE DADOS

7.1. As partes comprometem-se a tratar os dados pessoais de consumidores e colaboradores em conformidade com a Lei Geral de Protecao de Dados (LGPD - Lei 13.709/2018).

7.2. O PARCEIRO nao devera utilizar dados de consumidores obtidos atraves da plataforma para finalidades distintas do atendimento dos pedidos.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CLAUSULA 8 - DAS DISPOSICOES GERAIS

8.1. Este contrato e regido pelas leis da Republica Federativa do Brasil.

8.2. As partes elegem o foro da comarca de domicilio da PLATAFORMA para dirimir quaisquer controversias oriundas deste contrato.

8.3. A tolerancia de qualquer das partes quanto ao descumprimento de clausula deste contrato nao implicara em renuria ou novacao.

8.4. Alteracoes nas condicoes comerciais (comissoes, planos) serao comunicadas com antecedencia minima de 30 (trinta) dias, cabendo ao PARCEIRO aceitar ou rescindir o contrato.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ASSINATURA DIGITAL

Ao assinar digitalmente este contrato, o PARCEIRO declara que:
- Leu e compreendeu todas as clausulas acima;
- Concorda integralmente com os termos e condicoes estabelecidos;
- As informacoes fornecidas sao verdadeiras e completas;
- Esta ciente de que a assinatura digital possui validade juridica conforme a Medida Provisoria 2.200-2/2001.

Estabelecimento: {$partnerName}
Razao Social: {$razaoSocial}
{$docLabel}: {$docFormatted}
Endereco: {$fullAddress}
Plano: {$planLabel}
Data: {$dataAtual}
CONTRACT;

    return $contract;
}
